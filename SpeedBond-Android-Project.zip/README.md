# SpeedBond — Wi-Fi + Mobile Data Bandwidth Aggregator

## How to Get Your Installable `.apk` File (2 Easy Ways)

### Method 1: Build APK in the Cloud via GitHub Actions (No PC / Android Studio Needed)
1. Create a free repository on GitHub and upload the contents of this ZIP file.
2. Go to the **Actions** tab in your GitHub repository — the **Build SpeedBond APK** workflow will run automatically.
3. Once it finishes (~2 minutes), scroll down to **Artifacts** and download **`SpeedBond-debug-apk`** (`app-debug.apk`) directly to your Android phone.

### Method 2: Build Locally in Android Studio
1. Extract this ZIP file and open the folder in **Android Studio**.
2. Wait for Gradle Sync to finish.
3. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Your installable APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
