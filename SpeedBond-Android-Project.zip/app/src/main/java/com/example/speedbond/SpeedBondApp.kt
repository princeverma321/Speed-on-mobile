/*
 * ============================================================================
 * SpeedBond: Dual-Network Bandwidth Aggregator (Wi-Fi + Cellular) for Android
 * ============================================================================
 *
 * REQUIRED ANDROIDMANIFEST.XML CONFIGURATION:
 * ----------------------------------------------------------------------------
 * <manifest xmlns:android="http://schemas.android.com/apk/res/android"
 *     package="com.example.speedbond">
 *
 *     <!-- Crucial permissions to keep Cellular + Wi-Fi active simultaneously -->
 *     <uses-permission android:name="android.permission.INTERNET" />
 *     <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
 *     <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
 *     <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
 *     <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
 *
 *     <application
 *         android:label="SpeedBond"
 *         android:theme="@style/Theme.Material3.DayNight.NoActionBar">
 *
 *         <activity
 *             android:name=".MainActivity"
 *             android:exported="true">
 *             <intent-filter>
 *                 <action android:name="android.intent.action.MAIN" />
 *                 <category android:name="android.intent.category.LAUNCHER" />
 *             </intent-filter>
 *         </activity>
 *
 *         <service
 *             android:name=".DualPathVpnService"
 *             android:permission="android.permission.BIND_VPN_SERVICE"
 *             android:exported="false">
 *             <intent-filter>
 *                 <action android:name="android.net.VpnService" />
 *             </intent-filter>
 *         </service>
 *     </application>
 * </manifest>
 * ============================================================================
 */

package com.example.speedbond

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.VpnService
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.math.roundToInt

// ============================================================================
// 1. DATA MODELS & BONDING STATE
// ============================================================================

enum class BondingStrategy(val title: String, val description: String) {
    WEIGHTED_MULTIPATH(
        "Weighted Multi-Path Load Balance",
        "Distributes TCP sockets across Wi-Fi & Cellular proportional to real-time throughput"
    ),
    PARALLEL_CHUNK_BONDING(
        "Parallel Byte-Range Bonding",
        "Splits large downloads/streams into simultaneous chunks across both networks"
    ),
    LOWEST_LATENCY(
        "Lowest Latency + Failover",
        "Routes interactive traffic over the lowest-RTT link with instant zero-drop failover"
    )
}

data class LinkMetrics(
    val isAvailable: Boolean = false,
    val interfaceName: String = "Disconnected",
    val downloadMbps: Double = 0.0,
    val uploadMbps: Double = 0.0,
    val rttMs: Long = 0L,
    val bytesTransferred: Long = 0L
)

data class BondedDownloadState(
    val isRunning: Boolean = false,
    val url: String = "https://proof.ovh.net/files/100Mb.dat",
    val progress: Float = 0f,
    val wifiContributedBytes: Long = 0L,
    val cellContributedBytes: Long = 0L,
    val combinedSpeedMbps: Double = 0.0,
    val statusMessage: String = "Idle — Ready to bond Wi-Fi + Cellular"
)

// ============================================================================
// 2. DUAL NETWORK ENGINE (Simul-Active Wi-Fi + Cellular Binding)
// ============================================================================

class DualNetworkEngine(context: Context) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    var wifiNetwork: Network? = null
        private set

    @Volatile
    var cellularNetwork: Network? = null
        private set

    private val _wifiMetrics = MutableStateFlow(LinkMetrics())
    val wifiMetrics: StateFlow<LinkMetrics> = _wifiMetrics.asStateFlow()

    private val _cellMetrics = MutableStateFlow(LinkMetrics())
    val cellMetrics: StateFlow<LinkMetrics> = _cellMetrics.asStateFlow()

    private val wifiBytesCounter = AtomicLong(0L)
    private val cellBytesCounter = AtomicLong(0L)

    private var wifiCallback: ConnectivityManager.NetworkCallback? = null
    private var cellCallback: ConnectivityManager.NetworkCallback? = null
    private var monitorJob: Job? = null

    /**
     * Requests Android to keep BOTH Wi-Fi and Cellular interfaces up simultaneously.
     * Requires CHANGE_NETWORK_STATE permission.
     */
    fun startDualNetworkAcquisition() {
        stopDualNetworkAcquisition()

        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        wifiCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                wifiNetwork = network
                val linkProps = connectivityManager.getLinkProperties(network)
                _wifiMetrics.value = _wifiMetrics.value.copy(
                    isAvailable = true,
                    interfaceName = linkProps?.interfaceName ?: "wlan0"
                )
            }

            override fun onLost(network: Network) {
                if (wifiNetwork == network) {
                    wifiNetwork = null
                    _wifiMetrics.value = LinkMetrics(isAvailable = false)
                }
            }
        }

        cellCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cellularNetwork = network
                val linkProps = connectivityManager.getLinkProperties(network)
                _cellMetrics.value = _cellMetrics.value.copy(
                    isAvailable = true,
                    interfaceName = linkProps?.interfaceName ?: "rmnet_data0"
                )
            }

            override fun onLost(network: Network) {
                if (cellularNetwork == network) {
                    cellularNetwork = null
                    _cellMetrics.value = LinkMetrics(isAvailable = false)
                }
            }
        }

        connectivityManager.requestNetwork(wifiRequest, wifiCallback!!)
        connectivityManager.requestNetwork(cellRequest, cellCallback!!)

        startTelemetryLoop()
    }

    fun recordBytes(isWifi: Boolean, bytes: Long) {
        if (isWifi) {
            wifiBytesCounter.addAndGet(bytes)
        } else {
            cellBytesCounter.addAndGet(bytes)
        }
    }

    /**
     * Selects the optimal network for a new outbound socket based on real-time weight & RTT.
     */
    fun selectNextNetwork(strategy: BondingStrategy, connectionIndex: Long): Pair<Network?, Boolean> {
        val wifi = wifiNetwork
        val cell = cellularNetwork

        if (wifi != null && cell == null) return wifi to true
        if (cell != null && wifi == null) return cell to false
        if (wifi == null && cell == null) return null to true

        return when (strategy) {
            BondingStrategy.LOWEST_LATENCY -> {
                val wifiRtt = _wifiMetrics.value.rttMs.takeIf { it > 0 } ?: 50L
                val cellRtt = _cellMetrics.value.rttMs.takeIf { it > 0 } ?: 80L
                if (wifiRtt <= cellRtt) wifi to true else cell to false
            }
            BondingStrategy.WEIGHTED_MULTIPATH, BondingStrategy.PARALLEL_CHUNK_BONDING -> {
                // Calculate dynamic weight ratio from live throughput (default 60/40 Wi-Fi/Cell)
                val wifiSpeed = max(_wifiMetrics.value.downloadMbps, 5.0)
                val cellSpeed = max(_cellMetrics.value.downloadMbps, 5.0)
                val wifiShare = (wifiSpeed / (wifiSpeed + cellSpeed) * 10).roundToInt().coerceIn(1, 9)
                val useWifi = (connectionIndex % 10) < wifiShare
                if (useWifi) wifi to true else cell to false
            }
        }
    }

    private fun startTelemetryLoop() {
        monitorJob = scope.launch {
            var lastWifiBytes = 0L
            var lastCellBytes = 0L
            var lastMobileRx = TrafficStats.getMobileRxBytes()
            var lastTotalRx = TrafficStats.getTotalRxBytes()
            var tickCount = 0

            while (isActive) {
                delay(1000L)
                tickCount++

                val curMobileRx = TrafficStats.getMobileRxBytes()
                val curTotalRx = TrafficStats.getTotalRxBytes()
                val deltaMobileRx = max(0L, curMobileRx - lastMobileRx)
                val deltaWifiRx = max(0L, (curTotalRx - lastTotalRx) - deltaMobileRx)

                lastMobileRx = curMobileRx
                lastTotalRx = curTotalRx

                val appWifiNow = wifiBytesCounter.get()
                val appCellNow = cellBytesCounter.get()
                val appWifiDelta = max(0L, appWifiNow - lastWifiBytes)
                val appCellDelta = max(0L, appCellNow - lastCellBytes)
                lastWifiBytes = appWifiNow
                lastCellBytes = appCellNow

                val effectiveWifiBps = max(deltaWifiRx, appWifiDelta) * 8.0 / 1_000_000.0
                val effectiveCellBps = max(deltaMobileRx, appCellDelta) * 8.0 / 1_000_000.0

                if (wifiNetwork != null) {
                    _wifiMetrics.value = _wifiMetrics.value.copy(
                        downloadMbps = (effectiveWifiBps * 100).roundToInt() / 100.0,
                        bytesTransferred = appWifiNow
                    )
                }
                if (cellularNetwork != null) {
                    _cellMetrics.value = _cellMetrics.value.copy(
                        downloadMbps = (effectiveCellBps * 100).roundToInt() / 100.0,
                        bytesTransferred = appCellNow
                    )
                }

                // Measure per-interface RTT every 5 seconds
                if (tickCount % 5 == 1) {
                    wifiNetwork?.let { net ->
                        launch {
                            val rtt = measureRtt(net)
                            _wifiMetrics.value = _wifiMetrics.value.copy(rttMs = rtt)
                        }
                    }
                    cellularNetwork?.let { net ->
                        launch {
                            val rtt = measureRtt(net)
                            _cellMetrics.value = _cellMetrics.value.copy(rttMs = rtt)
                        }
                    }
                }
            }
        }
    }

    private fun measureRtt(network: Network): Long {
        return try {
            val start = System.currentTimeMillis()
            network.socketFactory.createSocket().use { socket ->
                socket.connect(InetSocketAddress("1.1.1.1", 443), 1500)
            }
            System.currentTimeMillis() - start
        } catch (_: Exception) {
            0L
        }
    }

    fun stopDualNetworkAcquisition() {
        monitorJob?.cancel()
        wifiCallback?.let { runCatching { connectivityManager.unregisterNetworkCallback(it) } }
        cellCallback?.let { runCatching { connectivityManager.unregisterNetworkCallback(it) } }
        wifiNetwork = null
        cellularNetwork = null
    }
}

// ============================================================================
// 3. MULTI-INTERFACE PARALLEL CHUNK DOWNLOADER (True Bandwidth Aggregation)
// ============================================================================

/**
 * Splits a single file download into fine-grained byte chunks and assigns concurrent
 * worker coroutines bound specifically to Wi-Fi and Cellular sockets.
 * Because workers pull from a shared lock-free queue, a faster network naturally
 * consumes more chunks while the slower network still adds 100% of its capacity.
 */
class BondedDownloadManager(
    private val context: Context,
    private val networkEngine: DualNetworkEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var activeJob: Job? = null

    private val _state = MutableStateFlow(BondedDownloadState())
    val state: StateFlow<BondedDownloadState> = _state.asStateFlow()

    data class ByteChunk(val index: Int, val startByte: Long, val endByte: Long)

    fun startBondedDownload(
        fileUrl: String,
        wifiThreads: Int = 3,
        cellularThreads: Int = 3
    ) {
        activeJob?.cancel()
        activeJob = scope.launch {
            try {
                _state.value = BondedDownloadState(
                    isRunning = true,
                    url = fileUrl,
                    statusMessage = "Probing remote server & preparing Wi-Fi + Cellular pipes..."
                )

                val totalLength = fetchContentLength(fileUrl)
                if (totalLength <= 0L) {
                    _state.value = _state.value.copy(
                        isRunning = false,
                        statusMessage = "Server does not support byte-range bonding (Content-Length missing)."
                    )
                    return@launch
                }

                val targetFile = File(context.cacheDir, "bonded_download.bin")
                RandomAccessFile(targetFile, "rw").use { it.setLength(totalLength) }

                // Divide into 1 MB chunks for dynamic work-stealing across Wi-Fi & Mobile Data
                val chunkSize = 1024L * 1024L
                val chunkQueue = ConcurrentLinkedQueue<ByteChunk>()
                var offset = 0L
                var idx = 0
                while (offset < totalLength) {
                    val end = minOf(offset + chunkSize - 1, totalLength - 1)
                    chunkQueue.add(ByteChunk(idx++, offset, end))
                    offset += chunkSize
                }

                val wifiDownloaded = AtomicLong(0L)
                val cellDownloaded = AtomicLong(0L)
                val startTime = System.currentTimeMillis()

                val progressUpdater = launch {
                    while (isActive) {
                        delay(250L)
                        val wBytes = wifiDownloaded.get()
                        val cBytes = cellDownloaded.get()
                        val sumBytes = wBytes + cBytes
                        val elapsedSec = max(0.25, (System.currentTimeMillis() - startTime) / 1000.0)
                        val combinedMbps = (sumBytes * 8.0 / 1_000_000.0) / elapsedSec

                        _state.value = _state.value.copy(
                            progress = (sumBytes.toFloat() / totalLength.toFloat()).coerceIn(0f, 1f),
                            wifiContributedBytes = wBytes,
                            cellContributedBytes = cBytes,
                            combinedSpeedMbps = (combinedMbps * 100).roundToInt() / 100.0,
                            statusMessage = "Bonding active: ${(sumBytes * 100 / totalLength)}% complete"
                        )
                    }
                }

                val workers = mutableListOf<Deferred<Unit>>()

                // Spawn Wi-Fi bound workers
                repeat(wifiThreads) {
                    workers.add(async {
                        runChunkWorker(
                            fileUrl = fileUrl,
                            outputFile = targetFile,
                            queue = chunkQueue,
                            isWifiWorker = true,
                            counter = wifiDownloaded
                        )
                    })
                }

                // Spawn Cellular bound workers
                repeat(cellularThreads) {
                    workers.add(async {
                        runChunkWorker(
                            fileUrl = fileUrl,
                            outputFile = targetFile,
                            queue = chunkQueue,
                            isWifiWorker = false,
                            counter = cellDownloaded
                        )
                    })
                }

                workers.awaitAll()
                progressUpdater.cancel()

                val totalElapsedSec = max(0.5, (System.currentTimeMillis() - startTime) / 1000.0)
                val finalMbps = (totalLength * 8.0 / 1_000_000.0) / totalElapsedSec
                _state.value = _state.value.copy(
                    isRunning = false,
                    progress = 1f,
                    wifiContributedBytes = wifiDownloaded.get(),
                    cellContributedBytes = cellDownloaded.get(),
                    combinedSpeedMbps = (finalMbps * 100).roundToInt() / 100.0,
                    statusMessage = "Completed (${formatBytes(totalLength)}) in ${totalElapsedSec.roundToInt()}s"
                )
            } catch (e: CancellationException) {
                _state.value = _state.value.copy(isRunning = false, statusMessage = "Download cancelled")
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    statusMessage = "Error: ${e.localizedMessage ?: "Connection failed"}"
                )
            }
        }
    }

    fun cancelDownload() {
        activeJob?.cancel()
    }

    private suspend fun runChunkWorker(
        fileUrl: String,
        outputFile: File,
        queue: ConcurrentLinkedQueue<ByteChunk>,
        isWifiWorker: Boolean,
        counter: AtomicLong
    ) = withContext(Dispatchers.IO) {
        while (isActive) {
            val chunk = queue.poll() ?: break
            val primaryNet = if (isWifiWorker) networkEngine.wifiNetwork else networkEngine.cellularNetwork
            val fallbackNet = if (isWifiWorker) networkEngine.cellularNetwork else networkEngine.wifiNetwork
            val activeNet = primaryNet ?: fallbackNet

            if (activeNet == null) {
                // Re-queue chunk and wait briefly if both links dropped
                queue.add(chunk)
                delay(500L)
                continue
            }

            val actuallyUsedWifi = (activeNet == networkEngine.wifiNetwork)

            try {
                // Open URLConnection explicitly over the selected Network interface
                val connection = (activeNet.openConnection(URL(fileUrl)) as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Range", "bytes=${chunk.startByte}-${chunk.endByte}")
                    connectTimeout = 8000
                    readTimeout = 8000
                }

                connection.inputStream.use { input ->
                    RandomAccessFile(outputFile, "rw").use { raf ->
                        raf.seek(chunk.startByte)
                        val buffer = ByteArray(32 * 1024)
                        while (isActive) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            raf.write(buffer, 0, read)
                            counter.addAndGet(read.toLong())
                            networkEngine.recordBytes(actuallyUsedWifi, read.toLong())
                        }
                    }
                }
                connection.disconnect()
            } catch (e: Exception) {
                // Fault tolerance: put failed chunk back into queue so the surviving link finishes it
                queue.add(chunk)
                delay(300L)
            }
        }
    }

    private fun fetchContentLength(fileUrl: String): Long {
        val net = networkEngine.wifiNetwork ?: networkEngine.cellularNetwork
        val conn = ((net?.openConnection(URL(fileUrl)) ?: URL(fileUrl).openConnection()) as HttpURLConnection)
        return try {
            conn.requestMethod = "HEAD"
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.contentLengthLong
        } finally {
            conn.disconnect()
        }
    }
}

// ============================================================================
// 4. LOCAL MULTIPATH PROXY + VPN SERVICE (System/App-Wide Socket Load Balancer)
// ============================================================================

/**
 * Runs a local Multipath SOCKS5 / HTTP CONNECT proxy on 127.0.0.1:10808 and configures
 * Android's VpnService with setHttpProxy() so apps automatically distribute concurrent
 * TCP connections across both Wi-Fi and Cellular interfaces.
 */
class DualPathVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private var proxyServerSocket: ServerSocket? = null
    private val connectionSequence = AtomicLong(0L)

    companion object {
        const val ACTION_START = "com.example.speedbond.START_VPN"
        const val ACTION_STOP = "com.example.speedbond.STOP_VPN"
        const val PROXY_PORT = 10808

        @Volatile
        var sharedNetworkEngine: DualNetworkEngine? = null

        @Volatile
        var activeStrategy: BondingStrategy = BondingStrategy.WEIGHTED_MULTIPATH

        private val _isVpnRunning = MutableStateFlow(false)
        val isVpnRunning: StateFlow<Boolean> = _isVpnRunning.asStateFlow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMultipathTunnel()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startMultipathTunnel()
        }
        return START_STICKY
    }

    private fun startMultipathTunnel() {
        if (_isVpnRunning.value) return
        _isVpnRunning.value = true

        serviceScope.launch {
            startLocalMultipathProxy()
        }

        // Configure Android VPN interface with local HTTP/SOCKS multipath proxy
        val builder = Builder()
            .setSession("SpeedBond Wi-Fi + Cellular Bonder")
            .setMtu(1500)
            .addAddress("10.188.0.2", 32)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            builder.setHttpProxy(android.net.ProxyInfo.buildDirectProxy("127.0.0.1", PROXY_PORT))
        }

        // Allow both underlying physical networks to carry multipath sockets
        val underlying = listOfNotNull(
            sharedNetworkEngine?.wifiNetwork,
            sharedNetworkEngine?.cellularNetwork
        ).toTypedArray()
        if (underlying.isNotEmpty()) {
            builder.setUnderlyingNetworks(underlying)
        }

        vpnInterface = builder.establish()
    }

    private suspend fun startLocalMultipathProxy() = withContext(Dispatchers.IO) {
        try {
            proxyServerSocket = ServerSocket(PROXY_PORT, 128)
            while (isActive && _isVpnRunning.value) {
                val clientSocket = proxyServerSocket?.accept() ?: break
                launch {
                    handleClientConnection(clientSocket)
                }
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Handles HTTP CONNECT and standard HTTP requests, binding each outbound socket
     * explicitly to either Wi-Fi or Cellular via Network.bindSocket() + VpnService.protect().
     */
    private suspend fun handleClientConnection(client: Socket) = withContext(Dispatchers.IO) {
        var remoteSocket: Socket? = null
        try {
            client.soTimeout = 15000
            val input = client.getInputStream()
            val output = client.getOutputStream()

            val headerLine = readAsciiLine(input)
            if (headerLine.isEmpty()) {
                client.close()
                return@withContext
            }

            // Consume remaining request headers
            val rawHeaders = StringBuilder(headerLine).append("\r\n")
            while (true) {
                val line = readAsciiLine(input)
                rawHeaders.append(line).append("\r\n")
                if (line.isEmpty()) break
            }

            val parts = headerLine.split(" ")
            if (parts.size < 2) {
                client.close()
                return@withContext
            }

            val method = parts[0]
            val targetSpec = parts[1]

            val (host, port) = parseHostPort(method, targetSpec)
            val engine = sharedNetworkEngine
            val seq = connectionSequence.incrementAndGet()
            val (chosenNetwork, isWifi) = engine?.selectNextNetwork(activeStrategy, seq) ?: (null to true)

            remoteSocket = Socket()
            // Protect socket from VPN loop and bind directly to chosen physical interface
            protect(remoteSocket)
            chosenNetwork?.bindSocket(remoteSocket)
            remoteSocket.connect(InetSocketAddress(host, port), 8000)

            if (method.equals("CONNECT", ignoreCase = true)) {
                output.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                output.flush()
            } else {
                remoteSocket.getOutputStream().write(rawHeaders.toString().toByteArray())
                remoteSocket.getOutputStream().flush()
            }

            // Bi-directional full-duplex relay with live byte accounting
            coroutineScope {
                val upstream = launch {
                    relayStream(input, remoteSocket.getOutputStream(), isWifi, engine)
                }
                val downstream = launch {
                    relayStream(remoteSocket.getInputStream(), output, isWifi, engine)
                }
                upstream.join()
                downstream.join()
            }
        } catch (_: Exception) {
        } finally {
            runCatching { remoteSocket?.close() }
            runCatching { client.close() }
        }
    }

    private fun relayStream(
        input: InputStream,
        output: OutputStream,
        isWifi: Boolean,
        engine: DualNetworkEngine?
    ) {
        val buf = ByteArray(16 * 1024)
        while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            output.write(buf, 0, read)
            output.flush()
            engine?.recordBytes(isWifi, read.toLong())
        }
    }

    private fun readAsciiLine(input: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1 || b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun parseHostPort(method: String, target: String): Pair<String, Int> {
        return if (method.equals("CONNECT", ignoreCase = true)) {
            val hostPort = target.split(":")
            val h = hostPort[0]
            val p = hostPort.getOrNull(1)?.toIntOrNull() ?: 443
            h to p
        } else {
            val url = URL(target)
            val p = if (url.port != -1) url.port else url.defaultPort.takeIf { it != -1 } ?: 80
            url.host to p
        }
    }

    private fun stopMultipathTunnel() {
        _isVpnRunning.value = false
        runCatching { proxyServerSocket?.close() }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
    }

    override fun onDestroy() {
        stopMultipathTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }
}

// ============================================================================
// 5. JETPACK COMPOSE UI & MAIN ACTIVITY
// ============================================================================

class MainActivity : ComponentActivity() {
    private lateinit var networkEngine: DualNetworkEngine
    private lateinit var downloadManager: BondedDownloadManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        networkEngine = DualNetworkEngine(applicationContext)
        DualPathVpnService.sharedNetworkEngine = networkEngine
        downloadManager = BondedDownloadManager(applicationContext, networkEngine)

        // Immediately request both Wi-Fi and Mobile Data networks to stay alive
        networkEngine.startDualNetworkAcquisition()

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF38BDF8),
                    secondary = Color(0xFFA855F7),
                    background = Color(0xFF0F172A),
                    surface = Color(0xFF1E293B)
                )
            ) {
                SpeedBondDashboard(
                    networkEngine = networkEngine,
                    downloadManager = downloadManager
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            networkEngine.stopDualNetworkAcquisition()
        }
    }
}

@Composable
fun SpeedBondDashboard(
    networkEngine: DualNetworkEngine,
    downloadManager: BondedDownloadManager
) {
    val context = LocalContext.current
    val wifiMetrics by networkEngine.wifiMetrics.collectAsState()
    val cellMetrics by networkEngine.cellMetrics.collectAsState()
    val downloadState by downloadManager.state.collectAsState()
    val isVpnRunning by DualPathVpnService.isVpnRunning.collectAsState()

    var selectedStrategy by remember { mutableStateOf(BondingStrategy.WEIGHTED_MULTIPATH) }
    var testUrl by remember { mutableStateOf(downloadState.url) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = Intent(context, DualPathVpnService::class.java).apply {
                action = DualPathVpnService.ACTION_START
            }
            context.startService(intent)
        }
    }

    val totalCombinedMbps = remember(wifiMetrics.downloadMbps, cellMetrics.downloadMbps, downloadState) {
        val liveSum = wifiMetrics.downloadMbps + cellMetrics.downloadMbps
        max(liveSum, if (downloadState.isRunning) downloadState.combinedSpeedMbps else 0.0)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SpeedBond Multipath",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Simultaneous Wi-Fi + Cellular Aggregator",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    StatusPill(
                        bothActive = wifiMetrics.isAvailable && cellMetrics.isAvailable,
                        anyActive = wifiMetrics.isAvailable || cellMetrics.isAvailable
                    )
                }
            }

            // Combined Speed Hero Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "COMBINED BONDED BANDWIDTH",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF38BDF8)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${String.format("%.2f", totalCombinedMbps)} Mbps",
                            fontSize = 40.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Contribution Split Bar
                        val wifiWeight = max(wifiMetrics.downloadMbps.toFloat(), 0.1f)
                        val cellWeight = max(cellMetrics.downloadMbps.toFloat(), 0.1f)
                        val wifiRatio by animateFloatAsState(
                            targetValue = wifiWeight / (wifiWeight + cellWeight),
                            label = "splitRatio"
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(CircleShape)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(wifiRatio.coerceIn(0.05f, 0.95f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF38BDF8))
                            )
                            Box(
                                modifier = Modifier
                                    .weight((1f - wifiRatio).coerceIn(0.05f, 0.95f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFA855F7))
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Wi-Fi: ${String.format("%.2f", wifiMetrics.downloadMbps)} Mbps",
                                fontSize = 12.sp,
                                color = Color(0xFF38BDF8)
                            )
                            Text(
                                text = "Cellular: ${String.format("%.2f", cellMetrics.downloadMbps)} Mbps",
                                fontSize = 12.sp,
                                color = Color(0xFFA855F7)
                            )
                        }
                    }
                }
            }

            // Dual Pipe Live Status Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    NetworkPipeCard(
                        modifier = Modifier.weight(1f),
                        title = "Wi-Fi Pipe",
                        accentColor = Color(0xFF38BDF8),
                        metrics = wifiMetrics
                    )
                    NetworkPipeCard(
                        modifier = Modifier.weight(1f),
                        title = "Cellular Pipe",
                        accentColor = Color(0xFFA855F7),
                        metrics = cellMetrics
                    )
                }
            }

            // System-Wide Multipath VPN Tunnel Toggle
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "System-Wide Multipath Tunnel",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isVpnRunning)
                                        "Active on 127.0.0.1:${DualPathVpnService.PROXY_PORT} — Load-balancing sockets"
                                    else
                                        "Routes concurrent connections across Wi-Fi & Mobile Data",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            Switch(
                                checked = isVpnRunning,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        val prepIntent = VpnService.prepare(context)
                                        if (prepIntent != null) {
                                            vpnPermissionLauncher.launch(prepIntent)
                                        } else {
                                            context.startService(
                                                Intent(context, DualPathVpnService::class.java).apply {
                                                    action = DualPathVpnService.ACTION_START
                                                }
                                            )
                                        }
                                    } else {
                                        context.startService(
                                            Intent(context, DualPathVpnService::class.java).apply {
                                                action = DualPathVpnService.ACTION_STOP
                                            }
                                        )
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Scheduling Strategy",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFCBD5E1)
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        BondingStrategy.entries.forEach { strategy ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = (selectedStrategy == strategy),
                                    onClick = {
                                        selectedStrategy = strategy
                                        DualPathVpnService.activeStrategy = strategy
                                    }
                                )
                                Column(modifier = Modifier.padding(start = 8.dp)) {
                                    Text(
                                        text = strategy.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White
                                    )
                                    Text(
                                        text = strategy.description,
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Multi-Interface Bonded Downloader & Speed Test
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Parallel Chunk Bonded Downloader",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Splits a single file into 1 MB byte-range chunks and pulls simultaneously over Wi-Fi and Cellular sockets",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = testUrl,
                            onValueChange = { testUrl = it },
                            label = { Text("Direct File URL (HTTP Range supported)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { downloadState.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = Color(0xFF38BDF8),
                            trackColor = Color(0xFF334155)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = downloadState.statusMessage,
                            fontSize = 12.sp,
                            color = Color(0xFFE2E8F0)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Wi-Fi pulled: ${formatBytes(downloadState.wifiContributedBytes)}",
                                fontSize = 12.sp,
                                color = Color(0xFF38BDF8)
                            )
                            Text(
                                text = "Cellular pulled: ${formatBytes(downloadState.cellContributedBytes)}",
                                fontSize = 12.sp,
                                color = Color(0xFFA855F7)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { downloadManager.startBondedDownload(testUrl) },
                                enabled = !downloadState.isRunning,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Start Bonded Download")
                            }
                            if (downloadState.isRunning) {
                                OutlinedButton(
                                    onClick = { downloadManager.cancelDownload() },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Stop")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkPipeCard(
    modifier: Modifier = Modifier,
    title: String,
    accentColor: Color,
    metrics: LinkMetrics
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (metrics.isAvailable) Color(0xFF22C55E) else Color(0xFFEF4444))
                )
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${String.format("%.2f", metrics.downloadMbps)} Mbps",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Interface: ${metrics.interfaceName}",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
            Text(
                text = "RTT: ${if (metrics.rttMs > 0) "${metrics.rttMs} ms" else "--"}",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
            Text(
                text = "Bonded Data: ${formatBytes(metrics.bytesTransferred)}",
                fontSize = 11.sp,
                color = Color(0xFFCBD5E1)
            )
        }
    }
}

@Composable
fun StatusPill(bothActive: Boolean, anyActive: Boolean) {
    val bgColor = when {
        bothActive -> Color(0xFF14532D)
        anyActive -> Color(0xFF713F12)
        else -> Color(0xFF7F1D1D)
    }
    val label = when {
        bothActive -> "DUAL-PIPE ACTIVE"
        anyActive -> "SINGLE LINK"
        else -> "OFFLINE"
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "${String.format("%.1f", kb)} KB"
    val mb = kb / 1024.0
    if (mb < 1024) return "${String.format("%.2f", mb)} MB"
    val gb = mb / 1024.0
    return "${String.format("%.2f", gb)} GB"
}
